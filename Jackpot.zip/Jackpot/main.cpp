#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    while(line !=0){
        scanf("%d",betAmmount);                                                                                  
        if(betAmmount < 1000){
             scanf("%[^\n]s",);
        }
    }    
    return EXIT_SUCCESS;
}
